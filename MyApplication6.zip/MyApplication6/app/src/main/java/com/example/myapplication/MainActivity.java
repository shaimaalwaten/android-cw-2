package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText x = findViewById(R.id.editTextTextPersonName);
        final EditText y = findViewById(R.id.editTextTextPersonName2);
        final EditText a = findViewById(R.id.editTextTextPersonName3);
        final EditText b = findViewById(R.id.editTextTextPersonName4);
        Button add = findViewById(R.id.button);
        TextView as = findViewById(R.id.textView2);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n1 = Integer.parseInt(x.getText().toString());
                int n2 = Integer.parseInt(y.getText().toString());
                int n3 = Integer.parseInt(a.getText().toString());
                int n4 = Integer.parseInt(b.getText().toString());
                int res = n1 + n2 + n3 + n4;
                Toast.makeText(MainActivity.this, res + "", Toast.LENGTH_SHORT).show();
            }
        });
    }}